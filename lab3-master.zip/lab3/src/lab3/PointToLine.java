package lab3;

public class PointToLine {
   
      
    public static void main(String[] args){
        BrokenLine line=new BrokenLine();
        boolean isX=true;
        double x=0,y=0;
        for (String num:args){
            if (isX) {
                x=Double.valueOf(num);
                isX=false;
            }
            else {
                y=Double.valueOf(num);
                isX=true;
            }
            if (isX){
                line.addPoint(new Point(x,y));
            }            
        }
        if (isX){
            int cnt=line.getLength();
            for (int i=0;i<cnt-1;i++){
                System.out.println(line.getLengthPart(i, i+1));
            }
            System.out.println(line.stringLine());
        }
        else{
            System.out.println("Последняя точка не имеет второй координаты.");
        }
    }
}
